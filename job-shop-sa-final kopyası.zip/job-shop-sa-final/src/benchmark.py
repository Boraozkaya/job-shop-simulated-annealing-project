from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json


@dataclass(frozen=True)
class JSSPInstance:
    code: str
    jobs: int
    machines: int
    operations: tuple[tuple[tuple[int, int], ...], ...]
    optimum: int
    difficulty: str
    source: str

    @property
    def operation_count(self) -> int:
        return self.jobs * self.machines


SELECTED_CODES = {
    "ft06": "Easy",
    "la01": "Moderate",
    "ft10": "Difficult",
    "la16": "Difficult",
    "la21": "Very Difficult",
}


def _data_lines(path: Path) -> list[str]:
    lines = []
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        lines.append(line)
    return lines


def _load_metadata(data_dir: Path) -> dict[str, int]:
    metadata_path = data_dir / "instances.json"
    payload = json.loads(metadata_path.read_text(encoding="utf-8"))
    return {
        item["name"]: int(item["optimum"])
        for item in payload
        if item.get("optimum") is not None
    }


def load_instance(path: str | Path, optimum: int, difficulty: str) -> JSSPInstance:
    path = Path(path)
    lines = _data_lines(path)
    jobs, machines = [int(token) for token in lines[0].split()]
    operations: list[tuple[tuple[int, int], ...]] = []
    for job_index, line in enumerate(lines[1 : 1 + jobs]):
        values = [int(token) for token in line.split()]
        if len(values) != machines * 2:
            raise ValueError(f"{path.name}: job {job_index} has {len(values)} values, expected {machines * 2}")
        job_ops = []
        for idx in range(0, len(values), 2):
            machine = values[idx]
            duration = values[idx + 1]
            job_ops.append((machine, duration))
        operations.append(tuple(job_ops))

    return JSSPInstance(
        code=path.stem.lower(),
        jobs=jobs,
        machines=machines,
        operations=tuple(operations),
        optimum=optimum,
        difficulty=difficulty,
        source="JSPLIB / OR-Library",
    )


def load_selected_instances(data_dir: str | Path) -> dict[str, JSSPInstance]:
    data_dir = Path(data_dir)
    optimum_by_code = _load_metadata(data_dir)
    instances = {}
    for code, difficulty in SELECTED_CODES.items():
        instances[code] = load_instance(data_dir / f"{code}.txt", optimum_by_code[code], difficulty)
    return instances
