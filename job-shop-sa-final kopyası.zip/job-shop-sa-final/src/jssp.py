from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .benchmark import JSSPInstance


@dataclass(frozen=True)
class ScheduledOperation:
    job: int
    operation: int
    machine: int
    start: int
    finish: int
    duration: int


@dataclass(frozen=True)
class Schedule:
    makespan: int
    sequence: tuple[int, ...]
    operations: tuple[ScheduledOperation, ...]


def decode_sequence(instance: JSSPInstance, sequence: list[int] | tuple[int, ...]) -> Schedule:
    if len(sequence) != instance.operation_count:
        raise ValueError(f"Sequence length {len(sequence)} does not match {instance.operation_count}")

    next_operation = [0] * instance.jobs
    job_ready = [0] * instance.jobs
    machine_ready = [0] * instance.machines
    scheduled: list[ScheduledOperation] = []

    for job in sequence:
        if job < 0 or job >= instance.jobs:
            raise ValueError(f"Invalid job id {job}")
        op_index = next_operation[job]
        if op_index >= instance.machines:
            raise ValueError(f"Job {job} appears too many times in the sequence")
        machine, duration = instance.operations[job][op_index]
        start = max(job_ready[job], machine_ready[machine])
        finish = start + duration
        job_ready[job] = finish
        machine_ready[machine] = finish
        next_operation[job] += 1
        scheduled.append(
            ScheduledOperation(
                job=job,
                operation=op_index,
                machine=machine,
                start=start,
                finish=finish,
                duration=duration,
            )
        )

    if any(count != instance.machines for count in next_operation):
        raise ValueError("Sequence does not schedule every operation exactly once")

    return Schedule(max(machine_ready), tuple(sequence), tuple(scheduled))


def spt_dispatch_sequence(instance: JSSPInstance) -> tuple[int, ...]:
    next_operation = [0] * instance.jobs
    sequence: list[int] = []
    while len(sequence) < instance.operation_count:
        candidates = [job for job in range(instance.jobs) if next_operation[job] < instance.machines]
        job = min(
            candidates,
            key=lambda j: (
                instance.operations[j][next_operation[j]][1],
                sum(duration for _, duration in instance.operations[j][next_operation[j] :]),
                j,
            ),
        )
        sequence.append(job)
        next_operation[job] += 1
    return tuple(sequence)


def job_order_sequence(instance: JSSPInstance) -> tuple[int, ...]:
    return tuple(job for job in range(instance.jobs) for _ in range(instance.machines))


def optimality_gap(value: int | float, optimum: int) -> float:
    return (float(value) - optimum) / optimum * 100.0


def schedule_to_dataframe(schedule: Schedule) -> pd.DataFrame:
    import pandas as pd

    return pd.DataFrame(
        [
            {
                "job": op.job + 1,
                "operation": op.operation + 1,
                "machine": op.machine + 1,
                "start": op.start,
                "finish": op.finish,
                "duration": op.duration,
            }
            for op in schedule.operations
        ]
    )


def save_schedule(schedule: Schedule, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    schedule_to_dataframe(schedule).to_csv(path, index=False)
