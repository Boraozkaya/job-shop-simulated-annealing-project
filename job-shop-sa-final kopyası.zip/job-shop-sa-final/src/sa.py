from __future__ import annotations

from dataclasses import dataclass
import math
import random
import time

from .benchmark import JSSPInstance
from .jssp import Schedule, decode_sequence, spt_dispatch_sequence


@dataclass(frozen=True)
class SAConfig:
    iterations: int = 5000
    initial_temperature_ratio: float = 0.30
    cooling_rate: float = 0.997
    min_temperature: float = 0.01
    seed: int = 2026
    record_interval: int = 50
    swap_probability: float = 0.45
    insert_probability: float = 0.35


@dataclass(frozen=True)
class SAResult:
    instance: str
    initial_makespan: int
    baseline_makespan: int
    best_makespan: int
    best_sequence: tuple[int, ...]
    iterations: int
    accepted_moves: int
    improving_moves: int
    runtime_seconds: float
    history: tuple[dict[str, int | float], ...]
    best_schedule: Schedule
    baseline_schedule: Schedule


def _swap(sequence: list[int], rng: random.Random) -> list[int]:
    i, j = rng.sample(range(len(sequence)), 2)
    neighbor = sequence.copy()
    neighbor[i], neighbor[j] = neighbor[j], neighbor[i]
    return neighbor


def _insert(sequence: list[int], rng: random.Random) -> list[int]:
    i, j = rng.sample(range(len(sequence)), 2)
    neighbor = sequence.copy()
    value = neighbor.pop(i)
    neighbor.insert(j, value)
    return neighbor


def _reverse(sequence: list[int], rng: random.Random) -> list[int]:
    i, j = sorted(rng.sample(range(len(sequence)), 2))
    neighbor = sequence.copy()
    neighbor[i : j + 1] = reversed(neighbor[i : j + 1])
    return neighbor


def _neighbor(sequence: tuple[int, ...], config: SAConfig, rng: random.Random) -> list[int]:
    roll = rng.random()
    mutable = list(sequence)
    if roll < config.swap_probability:
        return _swap(mutable, rng)
    if roll < config.swap_probability + config.insert_probability:
        return _insert(mutable, rng)
    return _reverse(mutable, rng)


def run_sa(instance: JSSPInstance, config: SAConfig, initial_sequence: tuple[int, ...] | None = None) -> SAResult:
    rng = random.Random(config.seed)
    baseline_sequence = spt_dispatch_sequence(instance)
    baseline_schedule = decode_sequence(instance, baseline_sequence)
    start_sequence = initial_sequence or baseline_sequence
    current = decode_sequence(instance, start_sequence)
    initial_makespan = current.makespan
    best = current
    temperature = max(config.min_temperature, current.makespan * config.initial_temperature_ratio)
    accepted_moves = 0
    improving_moves = 0
    history: list[dict[str, int | float]] = [
        {
            "iteration": 0,
            "current_makespan": current.makespan,
            "best_makespan": best.makespan,
            "temperature": temperature,
            "accepted": 0,
        }
    ]

    started = time.perf_counter()
    for iteration in range(1, config.iterations + 1):
        candidate_sequence = _neighbor(current.sequence, config, rng)
        candidate = decode_sequence(instance, candidate_sequence)
        delta = candidate.makespan - current.makespan
        accepted = False
        if delta <= 0:
            accepted = True
        else:
            accepted = rng.random() < math.exp(-delta / max(temperature, config.min_temperature))

        if accepted:
            current = candidate
            accepted_moves += 1
            if delta < 0:
                improving_moves += 1
            if current.makespan < best.makespan:
                best = current

        temperature = max(config.min_temperature, temperature * config.cooling_rate)
        if iteration % config.record_interval == 0 or iteration == config.iterations:
            history.append(
                {
                    "iteration": iteration,
                    "current_makespan": current.makespan,
                    "best_makespan": best.makespan,
                    "temperature": temperature,
                    "accepted": int(accepted),
                }
            )

    runtime = time.perf_counter() - started
    return SAResult(
        instance=instance.code,
        initial_makespan=initial_makespan,
        baseline_makespan=baseline_schedule.makespan,
        best_makespan=best.makespan,
        best_sequence=best.sequence,
        iterations=config.iterations,
        accepted_moves=accepted_moves,
        improving_moves=improving_moves,
        runtime_seconds=runtime,
        history=tuple(history),
        best_schedule=best,
        baseline_schedule=baseline_schedule,
    )
