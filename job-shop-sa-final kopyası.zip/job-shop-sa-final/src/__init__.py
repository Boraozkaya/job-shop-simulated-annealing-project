"""Job-shop scheduling with simulated annealing."""
