#!/bin/bash
cd "$(dirname "$0")"
echo "Rebuilding presentation table assets..."
echo
if command -v python3 >/dev/null 2>&1; then
  python3 build_presentation_assets.py
elif command -v python >/dev/null 2>&1; then
  python build_presentation_assets.py
else
  echo "Python was not found."
fi
echo
echo "Press Enter to close this window."
read
exit 0
