const path = require("path");
const fs = require("fs");
const pptxgen = require("pptxgenjs");

const ROOT = __dirname;
const OUT = path.join(ROOT, "presentation");
const FIG = path.join(ROOT, "outputs", "figures");
const TAB = path.join(ROOT, "outputs", "tables");
fs.mkdirSync(OUT, { recursive: true });

const pptx = new pptxgen();
pptx.layout = "LAYOUT_WIDE";
pptx.author = "ENM404 Project Group";
pptx.subject = "Job Shop Scheduling with Simulated Annealing";
pptx.title = "Job Shop Scheduling with Simulated Annealing";
pptx.company = "ENM404";
pptx.lang = "en-US";
pptx.theme = {
  headFontFace: "Aptos Display",
  bodyFontFace: "Aptos",
  lang: "en-US",
};
pptx.defineLayout({ name: "CUSTOM_WIDE", width: 13.333, height: 7.5 });
pptx.layout = "CUSTOM_WIDE";
pptx.margin = 0;

const C = {
  bg: "F4F0E7",
  ink: "162521",
  muted: "596760",
  green: "006D5B",
  teal: "2A9D8F",
  orange: "E76F51",
  yellow: "E9C46A",
  paper: "FFFDF7",
  line: "D7D0C4",
  dark: "16302B",
  dark2: "21443D",
  white: "FFFFFF",
};

function addBg(slide, fill = C.bg) {
  slide.background = { color: fill };
}

function addFooter(slide, n, source = "Source: Local Python experiments, JSPLIB / OR-Library benchmarks.") {
  slide.addShape(pptx.ShapeType.line, { x: 0.55, y: 7.13, w: 12.25, h: 0, line: { color: C.line, width: 1 } });
  slide.addText(source, { x: 0.55, y: 7.18, w: 10.5, h: 0.2, fontFace: "Aptos", fontSize: 7.5, color: C.muted });
  slide.addText(String(n), { x: 12.5, y: 7.14, w: 0.3, h: 0.25, fontFace: "Aptos", fontSize: 10, color: C.ink, bold: true, align: "right" });
}

function title(slide, kicker, heading, sub) {
  slide.addShape(pptx.ShapeType.rect, { x: 0.55, y: 0.48, w: 0.22, h: 0.04, fill: { color: C.teal }, line: { color: C.teal } });
  slide.addText(kicker.toUpperCase(), { x: 0.88, y: 0.37, w: 4.2, h: 0.25, fontFace: "Aptos", fontSize: 9.5, color: C.green, bold: true, margin: 0 });
  slide.addText(heading, { x: 0.55, y: 0.82, w: 8.9, h: 0.76, fontFace: "Georgia", fontSize: 24, color: C.ink, bold: true, margin: 0.02, fit: "shrink" });
  if (sub) slide.addText(sub, { x: 0.55, y: 1.64, w: 9.6, h: 0.46, fontFace: "Aptos", fontSize: 12, color: C.muted, margin: 0.02, fit: "shrink" });
}

function card(slide, x, y, w, h, head, body, accent = C.teal) {
  slide.addShape(pptx.ShapeType.rect, { x, y, w, h, fill: { color: C.paper }, line: { color: C.line, width: 1 } });
  slide.addShape(pptx.ShapeType.rect, { x, y, w: 0.08, h, fill: { color: accent }, line: { color: accent } });
  slide.addText(head, { x: x + 0.22, y: y + 0.14, w: w - 0.35, h: 0.25, fontFace: "Aptos", fontSize: 12, color: C.ink, bold: true, margin: 0 });
  slide.addText(body, { x: x + 0.22, y: y + 0.48, w: w - 0.35, h: h - 0.6, fontFace: "Aptos", fontSize: 10.2, color: C.muted, breakLine: false, margin: 0.02, fit: "shrink" });
}

function bullet(slide, items, x, y, w, h, opts = {}) {
  const text = items.map((v) => `• ${v}`).join("\n");
  slide.addText(text, { x, y, w, h, fontFace: "Aptos", fontSize: opts.size || 12, color: opts.color || C.ink, margin: 0.02, breakLine: false, fit: "shrink", valign: "mid" });
}

function img(slide, filename, x, y, w, h) {
  const p = path.join(FIG, filename);
  if (!fs.existsSync(p)) throw new Error(`Missing figure: ${p}`);
  slide.addImage({ path: p, x, y, w, h });
}

function csvRows(file) {
  const text = fs.readFileSync(path.join(TAB, file), "utf8").trim();
  const [header, ...rows] = text.split(/\r?\n/);
  return { header: header.split(","), rows: rows.map((r) => r.split(",")) };
}

const summary = csvRows("summary_results.csv").rows;
const insights = fs.readFileSync(path.join(TAB, "presentation_insights.txt"), "utf8");

let s = pptx.addSlide();
addBg(s);
s.addShape(pptx.ShapeType.rect, { x: 7.65, y: 0, w: 5.68, h: 7.5, fill: { color: C.dark }, line: { color: C.dark } });
s.addShape(pptx.ShapeType.rect, { x: 7.9, y: 0.48, w: 4.95, h: 6.28, fill: { color: C.dark2 }, line: { color: "315B52", width: 1 } });
s.addText("ENM404 PRODUCTION SCHEDULING PROJECT", { x: 0.88, y: 0.45, w: 3.2, h: 0.25, fontSize: 9, color: C.green, bold: true, margin: 0 });
s.addShape(pptx.ShapeType.rect, { x: 0.55, y: 0.56, w: 0.22, h: 0.04, fill: { color: C.teal }, line: { color: C.teal } });
s.addText("Job Shop Scheduling with Simulated Annealing", { x: 0.55, y: 0.94, w: 6.5, h: 0.92, fontFace: "Georgia", fontSize: 24, color: C.ink, bold: true, fit: "shrink", margin: 0.02 });
s.addText("A benchmark-driven study covering mathematical formulation, from-scratch SA implementation, parameter tuning, convergence analysis, and live code demonstration.", { x: 0.55, y: 2.0, w: 6.1, h: 0.62, fontSize: 12, color: C.muted, fit: "shrink", margin: 0.02 });
card(s, 0.55, 3.06, 6.15, 1.55, "Project Scope", "Problem type: Job Shop Scheduling Problem (JSSP)\nMetaheuristic: Simulated Annealing (SA)\nObjective: minimize makespan (Cmax)\nBenchmarks: FT and LA instances from JSPLIB / OR-Library", C.teal);
s.addText("Group Members", { x: 0.55, y: 5.12, w: 2.5, h: 0.28, fontSize: 15, color: C.ink, bold: true, margin: 0 });
bullet(s, ["Member 1", "Member 2", "Member 3", "Member 4", "Member 5"], 0.55, 5.54, 2.7, 1.0, { size: 12 });
s.addText("Evidence Track", { x: 8.18, y: 0.78, w: 2.6, h: 0.3, fontSize: 15, color: C.white, bold: true, margin: 0 });
bullet(s, ["Formal JSSP model", "Operation-sequence decoder", "Simulated Annealing design", "Parameter tuning", "5 benchmark instances", "10 runs per instance", "Convergence and Gantt visuals"], 8.18, 1.28, 3.95, 2.05, { size: 13, color: "ECF5F2" });
card(s, 8.18, 4.15, 3.95, 1.72, "Assignment Compliance", "The deck follows the brief structure: introduction, formulation, methodology, setup, results, discussion, conclusion, and live executable demo path.", C.orange);
addFooter(s, 1, "Source: ENM404 project brief and local experiment workflow.");

s = pptx.addSlide();
addBg(s);
title(s, "Problem Framing", "Job Shop is harder because every job has its own route.", "Unlike flow shop, each job can visit machines in a different technological order. The search must coordinate job precedence and machine capacity at the same time.");
card(s, 0.65, 2.35, 3.75, 2.1, "Decision", "Find operation start times and machine orderings that produce a feasible schedule.", C.teal);
card(s, 4.75, 2.35, 3.75, 2.1, "Constraint", "Each machine handles one operation at a time, and every job must follow its operation sequence.", C.orange);
card(s, 8.85, 2.35, 3.75, 2.1, "Objective", "Minimize makespan, Cmax, the completion time of the final operation in the schedule.", C.green);
bullet(s, ["Representation: each job id appears once for every operation", "Decoder converts a sequence into a feasible schedule", "SA searches by changing the operation sequence"], 1.1, 5.15, 10.7, 0.9, { size: 13 });
addFooter(s, 2);

s = pptx.addSlide();
addBg(s);
title(s, "Mathematical Model", "A solution is feasible only if precedence and machine capacity are both respected.", "The model minimizes Cmax while enforcing route order for each job and no overlap on any machine.");
card(s, 0.7, 2.22, 3.8, 2.75, "Notation", "n jobs, m machines\np[j,k]: processing time\nM[j,k]: required machine\nC[j,k]: completion time\nCmax: maximum completion time", C.teal);
card(s, 4.85, 2.22, 3.8, 2.75, "Constraints", "1. Job operation k+1 starts after operation k finishes.\n2. A machine processes one operation at a time.\n3. Operations are non-preemptive.", C.orange);
card(s, 9.0, 2.22, 3.25, 2.75, "Objective", "minimize Cmax\n\nCmax = max completion time over all scheduled operations", C.green);
addFooter(s, 3);

s = pptx.addSlide();
addBg(s);
title(s, "SA Method", "Simulated Annealing accepts some worse moves early to escape local traps.", "The algorithm starts from an SPT dispatch sequence, explores swap/insertion/reversal neighbors, and gradually reduces the probability of accepting worse schedules.");
card(s, 0.65, 2.25, 3.65, 2.65, "Initial Solution", "SPT dispatch sequence creates a quick feasible baseline. This baseline is intentionally simple, so SA improvement is visible.", C.teal);
card(s, 4.65, 2.25, 3.65, 2.65, "Neighborhoods", "Swap two positions\nInsert one operation token elsewhere\nReverse a segment\n\nAll moves preserve the required number of operations per job.", C.orange);
card(s, 8.65, 2.25, 3.65, 2.65, "Acceptance Rule", "If the candidate is better, accept it.\nIf worse, accept it with probability exp(-delta / T).\nT cools every iteration.", C.green);
addFooter(s, 4, "Source: Kirkpatrick et al. (1983); local implementation.");

s = pptx.addSlide();
addBg(s);
title(s, "Implementation", "The code is structured for both grading and live demonstration.", "The same scripts produce the tables, figures, and demo output used in the presentation.");
card(s, 0.65, 2.05, 3.75, 2.45, "Core Modules", "src/benchmark.py\n- Loads JSPLIB instances\n\nsrc/jssp.py\n- Decodes sequences\n- Computes schedules\n\nsrc/sa.py\n- Runs Simulated Annealing", C.teal);
card(s, 4.75, 2.05, 3.75, 2.45, "Experiment Scripts", "run_experiments.py\n- Tuning\n- 10-run experiments\n- CSV outputs\n- Chart outputs\n\nbuild_presentation_assets.py\n- Slide-ready tables", C.orange);
card(s, 8.85, 2.05, 3.75, 2.45, "Live Demo", "demo_run.py\n- Runs one instance fast\n- Prints optimum, baseline, best result, gap, accepted moves, and convergence trace.", C.green);
bullet(s, ["Recommended live command: python demo_run.py --instance ft10 --iterations 2500", "Full reproducibility command: python run_all.py"], 0.9, 5.25, 11.8, 0.65, { size: 13 });
addFooter(s, 5);

s = pptx.addSlide();
addBg(s);
title(s, "Benchmark Set", "Five standard Job Shop instances cover easy through very difficult cases.", "The selected FT and LA instances have known optimum references and are included locally in the data folder.");
img(s, "benchmark_table.png", 1.0, 2.05, 11.35, 3.4);
bullet(s, ["FT06 and LA01 validate small and moderate behavior", "FT10 and LA16 test 10x10 difficult cases", "LA21 raises scale to 150 operations"], 1.05, 5.76, 10.8, 0.65, { size: 12 });
addFooter(s, 6, "Source: JSPLIB / OR-Library benchmark files included under data/raw/.");

s = pptx.addSlide();
addBg(s);
title(s, "Parameter Tuning", "The selected SA setting balances solution quality and runtime.", "Six configurations were tested on FT10 and LA16 before running the final benchmark set.");
img(s, "tuning_table.png", 0.8, 1.9, 11.9, 3.45);
card(s, 1.05, 5.68, 3.55, 0.75, "Selected", "C3: 4500 iterations, T0 ratio 0.30, cooling 0.996", C.teal);
card(s, 4.9, 5.68, 3.55, 0.75, "Reason", "Lowest tuning score among tested configurations", C.orange);
card(s, 8.75, 5.68, 3.55, 0.75, "Runtime", "Mean tuning runtime stayed below one second", C.green);
addFooter(s, 7);

s = pptx.addSlide();
addBg(s);
title(s, "Final Results", "SA improves every selected benchmark against the SPT baseline.", "Each instance was run 10 times using the selected tuned configuration.");
img(s, "summary_table.png", 0.62, 1.9, 12.1, 3.55);
bullet(s, ["SA reached the known optimum on FT06 and LA01", "The difficult 10x10 and 15x10 cases keep non-trivial gaps", "All reported values come from run_experiments.py outputs"], 1.05, 5.75, 10.9, 0.72, { size: 12.4 });
addFooter(s, 8);

s = pptx.addSlide();
addBg(s);
title(s, "Gap Comparison", "The baseline is intentionally simple; SA shows the search gain clearly.", "Average gap versus the known optimum drops sharply across all selected instances.");
img(s, "gap_comparison.png", 0.95, 1.82, 11.2, 4.65);
addFooter(s, 9);

s = pptx.addSlide();
addBg(s);
title(s, "Search Dynamics", "Most improvement happens early, then cooling stabilizes the search.", "Convergence and temperature plots show how SA moves from exploration toward refinement.");
img(s, "convergence_curves.png", 0.55, 1.75, 6.25, 4.8);
img(s, "temperature_progress.png", 6.95, 1.75, 5.75, 4.8);
addFooter(s, 10);

s = pptx.addSlide();
addBg(s);
title(s, "Gantt Proof", "The schedule visual confirms that the decoder creates feasible machine timelines.", "The FT06 Gantt charts compare the SPT baseline and the best SA schedule from the experiment output.");
img(s, "gantt_ft06_spt.png", 0.65, 1.75, 5.95, 4.65);
img(s, "gantt_ft06_sa.png", 6.75, 1.75, 5.95, 4.65);
s.addText("SPT baseline", { x: 2.65, y: 6.34, w: 1.5, h: 0.2, fontSize: 10, color: C.muted, bold: true, align: "center" });
s.addText("Best SA schedule", { x: 8.9, y: 6.34, w: 1.8, h: 0.2, fontSize: 10, color: C.muted, bold: true, align: "center" });
addFooter(s, 11);

s = pptx.addSlide();
addBg(s);
title(s, "Findings", "The implementation is complete, reproducible, and strong enough for live explanation.", "The strongest classroom story is how SA moves from a simple dispatch schedule to a tuned benchmark result.");
card(s, 0.8, 2.15, 3.65, 2.75, "What Worked", "Reached optimum on FT06 and LA01\nImproved all baselines\nFast enough for live demo\nVisual outputs are generated by code", C.teal);
card(s, 4.85, 2.15, 3.65, 2.75, "Limitations", "Cooling parameters matter\nLarge instances retain gaps\nDecoder is reproducible but not a critical-path specialist", C.orange);
card(s, 8.9, 2.15, 3.65, 2.75, "How to Present", "Show the deck first\nRun demo_run.py live\nExplain SPT baseline, best found, gap, and convergence trace", C.green);
addFooter(s, 12);

s = pptx.addSlide();
addBg(s);
title(s, "Closing", "The project is ready for submission and live code demonstration.", "The final package contains the deck, source code, real benchmark data, generated outputs, and a short demo path.");
card(s, 0.85, 2.0, 3.7, 2.4, "Submission Files", "presentation/job-shop-sa-final.pptx\ndocs/final_summary.md\noutputs/tables/*.csv\noutputs/figures/*.png", C.teal);
card(s, 4.85, 2.0, 3.7, 2.4, "Live Commands", "python demo_run.py --instance ft10 --iterations 2500\n\npython run_all.py", C.orange);
card(s, 8.85, 2.0, 3.7, 2.4, "Group Members", "Member 1\nMember 2\nMember 3\nMember 4\nMember 5", C.green);
s.addText("All visual evidence in the deck is generated from the local experiment outputs.", { x: 1.1, y: 5.38, w: 11.1, h: 0.4, fontSize: 15, color: C.ink, bold: true, align: "center" });
addFooter(s, 13);

pptx.writeFile({ fileName: path.join(OUT, "job-shop-sa-final.pptx") });
