#!/bin/bash
cd "$(dirname "$0")"
echo "Job Shop Scheduling with Simulated Annealing"
echo "Running live demo..."
echo
if command -v python3 >/dev/null 2>&1; then
  python3 demo_run.py --instance ft10 --iterations 2500
elif command -v python >/dev/null 2>&1; then
  python demo_run.py --instance ft10 --iterations 2500
else
  echo "Python was not found. Install Python 3 and run: python demo_run.py --instance ft10 --iterations 2500"
fi
echo
echo "Press Enter to close this window."
read
exit 0
