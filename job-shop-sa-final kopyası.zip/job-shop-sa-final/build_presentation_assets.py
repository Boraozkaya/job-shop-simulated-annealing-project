from __future__ import annotations

from pathlib import Path
import os

PROJECT_ROOT = Path(__file__).resolve().parent
os.environ.setdefault("MPLCONFIGDIR", str(PROJECT_ROOT / ".mplconfig"))

try:
    import matplotlib.pyplot as plt
    import pandas as pd
except ModuleNotFoundError as exc:
    plt = None
    pd = None
    IMPORT_ERROR = exc
else:
    IMPORT_ERROR = None


def _resolve_output_dir(output_dir: str | Path) -> Path:
    output_path = Path(output_dir)
    if not output_path.is_absolute():
        output_path = PROJECT_ROOT / output_path
    return output_path


def _require_file(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required file not found: {path}")


def _safe_read_csv(path: Path) -> pd.DataFrame | None:
    try:
        return pd.read_csv(path)
    except PermissionError:
        print(
            "macOS blocked access to a packaged CSV file. "
            "The presentation assets are already included, so no regeneration is required."
        )
        print("For live code demonstration, run: python demo_run.py --instance ft10 --iterations 2500")
        return None


def _draw_table(df: pd.DataFrame, title: str, output_path: Path, font_size: int = 11) -> None:
    fig_height = max(2.25, 0.54 * (len(df) + 2))
    fig, ax = plt.subplots(figsize=(14, fig_height))
    ax.axis("off")
    ax.set_title(title, fontsize=16, fontweight="bold", loc="left", pad=18)
    table = ax.table(
        cellText=df.values,
        colLabels=df.columns,
        loc="upper left",
        cellLoc="center",
        colLoc="center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(font_size)
    table.scale(1, 1.55)
    for (row, _col), cell in table.get_celld().items():
        if row == 0:
            cell.set_facecolor("#16302b")
            cell.set_text_props(color="white", weight="bold")
        else:
            cell.set_facecolor("#f8f6f0" if row % 2 else "#edf4f2")
        cell.set_edgecolor("#d0d7de")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def create_assets(output_dir: str | Path = "outputs") -> None:
    if IMPORT_ERROR is not None:
        print(
            "Optional plotting libraries are not installed. "
            "The presentation assets are already included, so no regeneration is required."
        )
        print(f"Missing package detail: {IMPORT_ERROR}")
        print("For live code demonstration, run: python demo_run.py --instance ft10 --iterations 2500")
        return

    output_dir = _resolve_output_dir(output_dir)
    tables_dir = output_dir / "tables"
    figures_dir = output_dir / "figures"

    tuning_path = tables_dir / "parameter_tuning.csv"
    summary_path = tables_dir / "summary_results.csv"
    run_path = tables_dir / "run_level_results.csv"
    for path in (tuning_path, summary_path, run_path):
        _require_file(path)

    tuning_df = _safe_read_csv(tuning_path)
    summary_df = _safe_read_csv(summary_path)
    run_df = _safe_read_csv(run_path)
    if tuning_df is None or summary_df is None or run_df is None:
        return

    tuning_view = tuning_df[
        [
            "config_id",
            "iterations",
            "initial_temperature_ratio",
            "cooling_rate",
            "mean_gap_percent",
            "mean_runtime_seconds",
            "mean_acceptance_rate",
        ]
    ].copy()
    for col in ["initial_temperature_ratio", "cooling_rate", "mean_gap_percent", "mean_runtime_seconds", "mean_acceptance_rate"]:
        tuning_view[col] = tuning_view[col].map(lambda value: f"{value:.3f}")
    _draw_table(tuning_view, "Parameter Tuning Summary", figures_dir / "tuning_table.png", font_size=10)

    summary_view = summary_df[
        [
            "instance",
            "difficulty",
            "jobs",
            "machines",
            "optimum",
            "baseline_spt",
            "best_found",
            "mean_found",
            "mean_gap_percent",
            "mean_runtime_seconds",
        ]
    ].copy()
    summary_view["mean_found"] = summary_view["mean_found"].map(lambda value: f"{value:.1f}")
    summary_view["mean_gap_percent"] = summary_view["mean_gap_percent"].map(lambda value: f"{value:.2f}")
    summary_view["mean_runtime_seconds"] = summary_view["mean_runtime_seconds"].map(lambda value: f"{value:.2f}")
    _draw_table(summary_view, "Benchmark Result Summary", figures_dir / "summary_table.png", font_size=10)

    benchmark_view = summary_df[["instance", "difficulty", "jobs", "machines", "operations", "optimum"]].copy()
    benchmark_view["size"] = benchmark_view.apply(lambda row: f"{int(row.jobs)} x {int(row.machines)}", axis=1)
    benchmark_view = benchmark_view[["instance", "difficulty", "size", "operations", "optimum"]]
    _draw_table(benchmark_view, "Selected Job Shop Benchmark Set", figures_dir / "benchmark_table.png", font_size=11)

    best_row = summary_df.sort_values("best_gap_percent").iloc[0]
    hardest_row = summary_df.sort_values("mean_runtime_seconds", ascending=False).iloc[0]
    run_count = int(run_df["run"].max())
    notes = [
        "Presentation-ready findings:",
        f"- Experiments used {run_count} independent runs per benchmark instance.",
        f"- Strongest final result: {best_row['instance'].upper()} reached {best_row['best_gap_percent']:.2f}% gap.",
        f"- Highest runtime burden: {hardest_row['instance'].upper()} averaged {hardest_row['mean_runtime_seconds']:.2f} seconds.",
    ]
    for row in summary_df.itertuples():
        improvement = float(row.baseline_gap_percent) - float(row.mean_gap_percent)
        notes.append(
            f"- {row.instance.upper()} ({int(row.jobs)}x{int(row.machines)}): SA improved the average gap by {improvement:.2f} percentage points versus SPT."
        )
    (tables_dir / "presentation_insights.txt").write_text("\n".join(notes), encoding="utf-8")
    print(f"Presentation assets updated under {figures_dir}")


if __name__ == "__main__":
    create_assets()
