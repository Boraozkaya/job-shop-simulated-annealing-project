# Project Brief Compliance Checklist

This file maps the project brief requirements to the delivered package.

| Brief requirement | Where it is satisfied |
|---|---|
| Scheduling problem type | Job-Shop Scheduling throughout the deck and code |
| Metaheuristic algorithm | Simulated Annealing in `src/sa.py` |
| 5-person group placeholder | Cover slide has `Member 1` to `Member 5` |
| Formal problem definition | `docs/final_summary.md`, slides 2-3 |
| Decision variables, objective, constraints | `docs/final_summary.md`, slide 3 |
| Assumptions | `docs/final_summary.md` |
| From-scratch metaheuristic | `src/sa.py`, no black-box solver |
| Solution representation | Operation-based job sequence in `src/jssp.py` and `docs/final_summary.md` |
| Initialization strategy | SPT dispatch baseline in `src/jssp.py` |
| Neighborhood structure | swap, insertion, reversal in `src/sa.py` |
| Fitness/objective evaluation | makespan decoder in `src/jssp.py` |
| Stopping criteria | fixed SA iteration count in `SAConfig` |
| Problem-specific enhancement | feasible schedule decoder for JSSP precedence and machine constraints |
| Parameter tuning | `outputs/tables/parameter_tuning.csv`, slide 7 |
| 5 benchmark instances | FT06, LA01, FT10, LA16, LA21 |
| Easy/moderate/difficult classification | `docs/final_summary.md`, slide 6 |
| Established benchmark source | JSPLIB / OR-Library files under `data/raw/` |
| Objective value reporting | `outputs/tables/summary_results.csv`, slide 8 |
| Runtime reporting | `outputs/tables/summary_results.csv`, runtime chart |
| Convergence behavior | `outputs/figures/convergence_curves.png`, slide 10 |
| Comparison with known best solutions | optimum gap columns in `summary_results.csv` |
| Minimum 10 runs per instance | `run_experiments.py`, `run_level_results.csv` |
| Mean, standard deviation, best, worst | `summary_results.csv` |
| Baseline comparison | SPT baseline comparison in `summary_results.csv` and slide 9 |
| Strengths and weaknesses | `docs/final_summary.md`, slide 12 |
| Scalability discussion | runtime scaling figure and `docs/final_summary.md` |
| Presentation structure | 13-slide PowerPoint under `presentation/` |
| Live demonstration | `RUN_DEMO.command`, `RUN_DEMO_WINDOWS.bat`, `demo_run.py` |
| Reproducible modular code | `src/`, `run_all.py`, `requirements.txt` |
| Gantt visualization | `outputs/figures/gantt_ft06_sa.png` and slide 11 |
| Proper citation | `docs/final_summary.md` references and `outputs/tables/source_notes.txt` |

The package is designed so the PowerPoint and generated results can be reviewed
without running code, while `demo_run.py` gives a short live execution path for
the required demonstration.
