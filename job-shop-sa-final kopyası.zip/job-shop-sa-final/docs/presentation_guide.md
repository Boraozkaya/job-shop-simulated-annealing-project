# Presentation and Live Demo Guide

## Recommended presentation order

1. Open `presentation/job-shop-sa-final.pptx`.
2. Explain the problem: Job Shop Scheduling minimizes makespan while respecting
   job precedence and machine capacity.
3. Explain the algorithm: Simulated Annealing starts from an SPT baseline and
   improves it with swap, insertion, and reversal moves.
4. Show the benchmark and result slides.
5. Run the short demo command below.

## Live demo command

The easiest option is to double-click the included launcher:

- Mac: `RUN_DEMO.command`
- Windows: `RUN_DEMO_WINDOWS.bat`

Terminal alternative:

```bash
python demo_run.py --instance ft10 --iterations 2500
```

## What to explain from the terminal output

- `Known optimum/reference`: published best reference value.
- `SPT baseline`: simple dispatch solution before metaheuristic improvement.
- `Best found by SA`: best makespan found by Simulated Annealing.
- `Best gap`: percentage difference from the known optimum.
- `Accepted moves`: how many candidate moves SA accepted.
- `Convergence history`: how the best solution changes over iterations.

## Full regeneration command

```bash
python run_all.py
```

This reruns parameter tuning, all benchmark experiments, and table/figure asset
generation. It is better to use `demo_run.py` during the live presentation
because it finishes quickly.

## CSV files

- `parameter_tuning.csv`: tested SA settings and selected configuration.
- `run_level_results.csv`: every independent run.
- `summary_results.csv`: main result table used in the deck.
- `convergence_history.csv`: iteration-level convergence data.
- `best_schedules.csv`: operation timings for the best schedules.
