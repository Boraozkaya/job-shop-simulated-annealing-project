# Job Shop Scheduling with Simulated Annealing

## Project definition

- Scheduling type: Job Shop Scheduling Problem (JSSP)
- Metaheuristic: Simulated Annealing (SA)
- Objective: Minimize makespan (`Cmax`)
- Baseline heuristic: Shortest Processing Time (SPT) dispatch sequence

## Mathematical model

There are `n` jobs and `m` machines. Each job has a fixed technological route:
operation 1 must be processed before operation 2, and so on. Each operation has
one required machine and one processing time.

- Processing time of job `j`, operation `k`: `p[j,k]`
- Required machine of job `j`, operation `k`: `M[j,k]`
- Completion time: `C[j,k]`
- Objective: `min Cmax`, where `Cmax` is the latest operation completion time
- Decision variable: operation start time `S[j,k]`
- Sequencing variable: binary ordering relation between operations assigned to
  the same machine

Core constraints:

1. Each machine processes at most one operation at a time.
2. Each job follows its predefined operation order.
3. Operations are non-preemptive.
4. The schedule minimizes the maximum completion time.

Assumptions:

- All jobs and processing times are known before scheduling starts.
- Machines are continuously available.
- Setup times and transportation times are not modeled separately.
- Each operation must be processed on its predefined machine.
- Operations cannot be interrupted once started.

## Algorithm design

The solver was written from scratch and includes:

- JSPLIB / OR-Library benchmark parser
- Operation-based JSSP sequence representation
- Feasible schedule decoder
- SPT dispatch baseline
- Simulated Annealing with three neighborhood operators:
  - swap
  - insertion
  - reversal
- Temperature cooling schedule
- Parameter tuning driver
- Multi-run experiment runner
- Convergence, temperature, gap, runtime, and Gantt visualizations

## Benchmark set

| Instance | Size | Difficulty | Known optimum |
|---|---:|---|---:|
| FT06 | 6 x 6 | Easy | 55 |
| LA01 | 10 x 5 | Moderate | 666 |
| FT10 | 10 x 10 | Difficult | 930 |
| LA16 | 10 x 10 | Difficult | 945 |
| LA21 | 15 x 10 | Very Difficult | 1046 |

Difficulty justification:

- `FT06` is the smallest selected case and is used as the easy correctness
  check.
- `LA01` is a moderate case because it has more jobs than `FT06` while still
  remaining small enough for stable repeated runs.
- `FT10` and `LA16` are 10 x 10 cases with 100 operations and are used as
  difficult benchmarks.
- `LA21` has 150 operations and showed the largest runtime burden in the final
  experiments, so it is labeled very difficult.

## Parameter tuning

The final configuration was selected after comparing six SA settings on `FT10`
and `LA16`.

- Selected configuration ID: `C3`
- `iterations = 4500`
- `initial_temperature_ratio = 0.30`
- `cooling_rate = 0.996`
- Mean tuning gap: `8.34%`
- Mean tuning runtime: `0.56 s`

## Final experimental results

Each benchmark instance was run 10 times.

| Instance | SPT baseline | Best found | Mean found | Mean gap (%) | Avg. runtime (s) |
|---|---:|---:|---:|---:|---:|
| FT06 | 118 | 55 | 55.0 | 0.00 | 0.21 |
| LA01 | 1353 | 666 | 669.5 | 0.53 | 0.29 |
| FT10 | 2888 | 1002 | 1029.8 | 10.73 | 0.57 |
| LA16 | 3611 | 979 | 1005.6 | 6.41 | 0.57 |
| LA21 | 4688 | 1107 | 1170.4 | 11.89 | 0.85 |

## Main findings

- All reported results were generated from the Python code in this package.
- SA reached the known optimum on `FT06` and `LA01`.
- SA improved the SPT baseline on all five benchmark instances.
- The largest baseline improvement was observed on the larger difficult cases,
  where the SPT dispatch rule was far from optimal.
- `LA21` was the hardest selected instance because it has 150 operations and the
  largest average runtime.
- Convergence plots show rapid early improvements followed by smaller late-stage
  refinements as the temperature cools.

## Strengths and weaknesses

Strengths:

- Clear from-scratch implementation
- Real benchmark data
- Reproducible experiment pipeline
- Multiple neighborhood operators
- Strong live-demo capability
- Interpretable visual outputs

Weaknesses:

- SA quality depends on cooling parameters
- Larger instances still retain a non-trivial optimality gap
- The operation-sequence decoder is simple and prioritizes reproducibility over
  advanced critical-path local search

## Files produced

- `run_experiments.py`: full experiment runner
- `demo_run.py`: short live demo script
- `run_all.py`: one-command pipeline for experiments plus table asset generation
- `build_presentation_assets.py`: creates slide-ready table figures
- `outputs/tables/`: CSV and metadata outputs
- `outputs/figures/`: charts and Gantt visuals
- `presentation/`: final presentation deck

## References

1. H. Fisher and G. L. Thompson, "Probabilistic learning combinations of local
   job-shop scheduling rules," in *Industrial Scheduling*, 1963.
2. S. Lawrence, *Resource constrained project scheduling: an experimental
   investigation of heuristic scheduling techniques*, Carnegie-Mellon
   University, 1984.
3. S. Kirkpatrick, C. D. Gelatt, and M. P. Vecchi, "Optimization by Simulated
   Annealing," *Science*, 220(4598), 671-680, 1983.
4. OR-Library / JSPLIB benchmark instance collection.
